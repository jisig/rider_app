package com.example.google_mao

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
