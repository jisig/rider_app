import 'package:flutter/material.dart';

const String google_api_key = "API_KEY";
const Color primaryColor = Color(0xFF7B61FF);
const double defaultPadding = 16.0;
